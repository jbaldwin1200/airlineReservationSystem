package airplaneprojectnogui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class MainMenu {

    int flightNum;
    int flightDate;
    int departTime;
    int arriveTime;
    String departCity;
    String destCity;
    int availableSeats;

    Scanner input = new Scanner(System.in);

    public void addFlight() {
        System.out.println("Enter the flight number: ");
        flightNum = input.nextInt();
        System.out.println("Enter the flight date: ");
        flightDate = input.nextInt();
        System.out.println("Enter the departure time: ");
        departTime = input.nextInt();
        System.out.println("Enter the arrival time: ");
        arriveTime = input.nextInt();
        System.out.println("Enter the departure city: ");
        departCity = input.nextLine();
        System.out.println("Enter the destination city: ");
        destCity = input.nextLine();
        System.out.println("Enter the number of available seats: ");
        availableSeats = input.nextInt();
    }

    public void newReservation() {
        System.out.println("What is the flight number? ");
        flightNum = input.nextInt();
        System.out.println("Enter the new passenger ID and Name: ");
        //display seat map
        System.out.println("Enter the seat number you would like: ");
        //update available seats on flight
        //add reservation to reservations.txt
        //update flight seat map
    }

    public void createFlightsInfo() throws FileNotFoundException, IOException {
        try (Formatter output = new Formatter("flights.txt")) {
            Scanner input = new Scanner(System.in);
            System.out.printf("%d%n%d%n%d%n%d%n%s%n%s%n%d%n? ",
                    "Enter flight number, flight date, departure time, arrival time,"
                    + "departure city, destination city, and the number of available seats.");
            System.out.println("Enter -1 to quit: ");
            flightNum = input.nextInt();
            //this while statement will be deleted when transferred to GUI
            //Instead, this method will run everytime a button is clicked
            while (flightNum != -1) {
                try {
                    //output new record to file; assumes valid input
                    output.format("%d  %d  %d  %d  %s  %s  %d", flightNum,
                            input.next(), input.next(), input.next(), input.next(), input.nextLine(), input.nextLine(), input.nextInt());
                } catch (NoSuchElementException elementException) {
                    System.err.println("Invalid input. Please try again.");
                    input.nextLine(); //discard input so user can try again
                }
                flightNum = input.nextInt();
                System.out.println("? ");
            }
        } catch (SecurityException | FileNotFoundException
                | FormatterClosedException e) {
            e.printStackTrace();
        }

    }
}
